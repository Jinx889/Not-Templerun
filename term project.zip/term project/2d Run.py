#2D Run

#Author: Abigail Lopez
#Date: 11//21

from time import sleep
import sys
import pygame

pygame.mixer.init()
pygame.init()

from random import randint

WIDTH        = 900
HEIGHT       = 700

GROUND_COLOR   = (50, 0, 0)

GROUND_LEVEL   = HEIGHT - 20

JUMPER_DX = 2

DISTANCE = 0
GRAVITY = .7 # How strong is gravity?
JUMP_DY = 20   # How strong does it jump?
screen = pygame.display.set_mode((WIDTH,HEIGHT))   # Construct the screen and
pygame.display.set_caption("Run!")       #### set its caption.

pygame.mixer.music.load("chase.mp3")
pygame.mixer.music.play(-1)
######################
class Player(pygame.sprite.Sprite):

    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        #Prototype Player -- A red box
        self.image = pygame.Surface((40,40))
        self.image.fill( (227, 0, 0) )
        self.rect = self.image.get_rect();
        self.rect.centerx = (200)
        self.rect.bottom = GROUND_LEVEL
        self.dy = 0
        self.jumping = False
        self.faceRight = True
    def jump(self) :
        # Only jump if not already jumping
        if not self.jumping :
            self.jumping = True
            self.dy = -JUMP_DY   # Start it moving upwards
            
    def update(self) :
        if self.jumping :
            self.rect.centery += self.dy
            self.dy += GRAVITY

            # Land on the ground
            if self.rect.bottom >= GROUND_LEVEL :
                self.dy = 0
                self.jumping = False
                self.rect.bottom = GROUND_LEVEL

            # Don't go above the top window edge
            if self.rect.top < 0 :
                self.rect.top = 0
                self.dy = 0

        # Move left and right
        keys = pygame.key.get_pressed()
        
        if keys[pygame.K_LEFT]:
            #DISTANCE += 1
            if (self.rect.left > 0):
                self.rect.centerx -= JUMPER_DX
            if self.faceRight == True :
                self.faceRight = False
                self.image = pygame.transform.flip(self.image, True, False)
                
        if keys[pygame.K_RIGHT]:
            #DISTANCE += 1 
            if (self.rect.right):
                self.rect.centerx += JUMPER_DX
            if self.faceRight == False:
                self.faceRight = True
                self.image = pygame.transform.flip(self.image, True, False)

    def get_pos(self):
        return self.rect.centerx
######################
class Monster(pygame.sprite.Sprite):
    def __init__(self):#(self, player):
        pygame.sprite.Sprite.__init__(self)#(self, player)
        #Prototype monster -- A black box
        self.image = pygame.Surface((40,40))
        self.image.fill( (225, 225, 225) )
        self.rect = self.image.get_rect();
        self.rect.bottom = GROUND_LEVEL
        self.dx = 1
        
    def update(self, player) :
        player_pos = player.get_pos()
        if player_pos > self.rect.centerx:
            self.rect.centerx += self.dx
        else:
            self.rect.centerx -= self.dx
######################
class Hurdle(pygame.sprite.Sprite):
    
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
    #Prototype hurdle -- blue box
        self.image = pygame.Surface((20,40))
        self.image.fill( (0, 85, 255) )
        self.rect = self.image.get_rect();
        self.rect.bottom = GROUND_LEVEL
        self.rect.centerx = 800
        self.dx = 2

    def update(self):
        self.rect.centerx -= self.dx
        if self.rect.left < 0:
            self.reset()

    def reset(self):
        #self.rect.left = 0
        self.rect.centerx = 850
######################
class Pit(pygame.sprite.Sprite):
    
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        #Prototype pit -- A green box
        self.image = pygame.Surface((100,400))
        self.image.fill( (77, 62, 50) )
        self.rect = self.image.get_rect();
        self.rect.bottom = GROUND_LEVEL + 390  
        self.rect.centerx = 900
        self.dx = 2
        
    def update(self):
        self.rect.centerx -= self.dx
        if self.rect.left < 0:
            self.reset()

    def reset(self):
        self.rect.centerx = WIDTH * (1 + randint(1, 10) / 10)
######################
class Label(pygame.sprite.Sprite):

    def __init__(self, textStr, center, fontType, fontSize, textColor):
        pygame.sprite.Sprite.__init__(self)
        self.font = pygame.font.Font(fontType, fontSize)
        self.text = textStr
        self.center = center
        self.textColor = textColor

    # self.update() - Render the text on the label.
    def update(self):
        self.image = self.font.render(self.text, 1, self.textColor)
        self.rect = self.image.get_rect()
        self.rect.center = self.center

#####################
class Star(pygame.sprite.Sprite):
    
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
    #Prototype hurdle -- blue box
        self.image = pygame.image.load("star.png")
        self.image = pygame.transform.scale(self.image, (WIDTH // 20, HEIGHT// 20))
        self.image = self.image.convert()
        self.image.set_colorkey( self.image.get_at((1,1)) )
        self.rect = self.image.get_rect()
        self.reset()
        self.dx = 2

    def update(self):
        self.rect.centerx -= self.dx
        if self.rect.left < 0:
            self.reset()
        
    def reset(self):
        self.rect.centerx = WIDTH * (1 + randint(1, 10) / 10)
        self.rect.centery = (randint(550, 650))
######################
def titleScreen():
    clock = pygame.time.Clock()

# Construct a yellow background surface the same size as the screen.
    background = pygame.Surface(screen.get_size())
    backImage = pygame.image.load("background.png")
    backImage = backImage.convert()  
    background.blit(backImage, (0,0))
    
                 # Convert graphics format.                  
    screen.blit(background, (0,0))


    
    backLocation = 0
    
    #label for title/game instructions
    titleMsg = Label("Run!", (WIDTH / 2,200), None, 60, (0,0,0))
    instructMsg = Label("Use Up and Down to jump and avoid the pits and hurdles,", (WIDTH / 2, 260), None, 40, (0,0,0))
    leftMsg = Label("Use the arrow key to move left, don't let the monster catch you or game over!", (WIDTH / 2, 320), None, 25, (0,0,0))
    startMsg = Label("Click to start", (WIDTH / 2,400), None, 30,(0,0,0))
    # Add the labels to a group  
    labelGroup = pygame.sprite.Group(titleMsg, startMsg, instructMsg, leftMsg)

    
    clock = pygame.time.Clock()
    keepGoing = True

    while keepGoing:
        clock.tick(30)  
        
        
        backLocation -= 2
        background.blit(backImage, (backLocation,0))
        screen.blit(backImage, (backLocation, 0))

        #if backLocation > screen.get_width() :
            #background.blit(backImage,(backLocation,0))
            #screen.blit(backImage, (backLocation, 0))
        

        

        for event in pygame.event.get():      # Handle any events
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN: # Title screen ends
                keepGoing = False                      # when mouse clicked
            elif event.type == pygame.KEYDOWN:         # or any key pressed
                keepGoing = False

          
        
              
        labelGroup.clear(screen, background)  # Update the display
        
        labelGroup.update()
        
        labelGroup.draw(screen)
        
        
        pygame.display.flip()
        
######################
def game():
    background = pygame.Surface(screen.get_size())  # Construct background
    backImage = pygame.image.load("background.png")
    backImage = backImage.convert()  
    background.blit(backImage, (0,0))              # Convert graphics format.
    
    screen.blit(background, (0,0))
    clock = pygame.time.Clock()

    lives = 3

    stars = 0

    backLocation = 0

#Lives/Distance Initial
    lifeMsg = Label("You have 3 lives", (200,30), None, 40, (0,0,0))

    starMsg = Label("You have 0 stars", (600, 30), None, 40, (0,0,0))
    
    labelGroup = pygame.sprite.Group(lifeMsg, starMsg)
#Construct Game Entities
    player = Player()
    monster = Monster()
    hurdle1 = Hurdle()
    hurdle2 = Hurdle()
    pit1 = Pit()
    pit2 = Pit()
    star = Star()
    star2 = Star()
    star3 = Star()

    hurdleList = pygame.sprite.Group(hurdle1, hurdle2)
    playerGroup = pygame.sprite.Group(player)
    pitList = pygame.sprite.Group(pit1, pit2)
    monsterGroup = pygame.sprite.Group(monster)
    starGroup = pygame.sprite.Group(star, star2, star3)

#Start the Game?
    keepGoing = True               # Signals the game is over.
    win = False
    while keepGoing:
        clock.tick(30)

        lifeMsg.text = f"You have {lives} lives left"

        starMsg.text = f"You have {stars} stars collected"
        
        backLocation -= 2.5
        background.blit(backImage, (backLocation,0))
        screen.blit(backImage, (backLocation, 0))
        
#Movement
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE or event.key == pygame.K_q:
                    keepGoing = False
                if event.key == pygame.K_SPACE or event.key == pygame.K_UP:
                    player.jump()

        if pygame.sprite.spritecollide(player, pitList, False) :
                print("Oh no!")
                keepGoing = False
        if pygame.sprite.spritecollide(player, hurdleList, False) :
                print("hurdle")
                lives -= 1
                if lives <= 0 :
                    win = False
                    keepGoing = False
        if pygame.sprite.spritecollide(player, monsterGroup, False) :
                print("monster")
                win = False
                keepGoing = False
        if pygame.sprite.spritecollide(player, starGroup, True):
            stars += 1
            if stars == 3 :
                print("win")
                win = True
                keepGoing = False
                      
        playerGroup.clear(screen, background)
        monsterGroup.clear(screen, background)
        hurdleList.clear(screen, background)
        pitList.clear(screen, background)
        labelGroup.clear(screen, background)
        starGroup.clear(screen, background)
    
        playerGroup.update()
        monsterGroup.update(player)
        hurdleList.update()
        pitList.update()
        labelGroup.update()
        starGroup.update()
    
        pitList.draw(screen)
        playerGroup.draw(screen)
        monsterGroup.draw(screen)
        hurdleList.draw(screen)
        labelGroup.draw(screen)
        starGroup.draw(screen)
        
        pygame.display.flip()

    return win, stars
######################
def main():

    titleScreen()
    
    replay = True
    while replay :
        win, stars = game()                # Play the game.
        replay = playAgain(win,stars)
        
    endMessage()     # Final "The End" Screen.

######################
def endMessage():
    
    background = pygame.Surface(screen.get_size()) # Construct a background
    background = background.convert()
    background.fill((35, 168, 71))
    screen.blit(background, (0,0))   # Blit background to screen only once.

    # Construct a Label object to display the message and add it to a group.
    label1 = Label("Thanks for playing!", (WIDTH / 2,210), None, 60, (0,0,0))
    label2 = Label("Abigail Lopez", (WIDTH / 2,320), None, 30, (0,0,0))
    label3 = Label("11/18/2021", (WIDTH / 2,360), None, 30, (0,0,0))
    labelGroup = pygame.sprite.Group( label1, label2, label3 )

    clock = pygame.time.Clock()
    keepGoing = True
    frames = 0                  # 5 seconds will be 150 frames

    while keepGoing:
    
        clock.tick(30)          # Frame rate 30 frames per second.
        frames = frames + 1     # Count the number of frames displayed
        if frames == 150:        # After 5 seconds end the message display
            keepGoing = False 

        for event in pygame.event.get():    # Impatient people can quit earlier
            if (event.type == pygame.QUIT or
                event.type == pygame.KEYDOWN or
                event.type == pygame.MOUSEBUTTONDOWN) :
                keepGoing = False

        labelGroup.clear(screen, background)
        labelGroup.update()
        labelGroup.draw(screen)

        pygame.display.flip()
        
######################
def playAgain(winLose,stars):
    
    background = pygame.Surface(screen.get_size()) # Construct a background
    background = background.convert()
    loseSound = pygame.mixer.Sound("lose.wav")
    if winLose:
        fillColor = ((0,0,0))
        labelText = "You Win!!"
        labelColor = ((0,0,0))
    else:
        pygame.mixer.music.fadeout(1000)
        loseSound.play()
        fillColor = ((0,0,0))
        labelText = "You Lose..."
        labelColor = ((0,0,0))

    background.fill((52, 86, 140))
    screen.blit(background, (0,0))
    
    # Construct Labels
    labelstat = Label(f"You had {stars} stars collected.", (WIDTH / 2, 150), None, 30, labelColor)
    label0 = Label(labelText, (WIDTH / 2,110), None, 60, labelColor)
    label1 = Label("Play again?", (WIDTH / 2,210), None, 60, labelColor)
    label2 = Label("(Y/N)", (WIDTH / 2,280), None, 60, labelColor)
    labelGroup = pygame.sprite.Group( label0, label1, label2, labelstat )

    clock = pygame.time.Clock()
    keepGoing = True
    replay = False

    while keepGoing:
    
        clock.tick(30)

        for event in pygame.event.get():
            if event.type == pygame.QUIT or event.type == pygame.MOUSEBUTTONDOWN:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                keepGoing = False
                if event.key == pygame.K_y:
                    replay = True
                if event.key == pygame.K_n:
                    replay = False

        labelGroup.clear(screen, background)
        labelGroup.update()
        labelGroup.draw(screen)

        pygame.display.flip()
        
    return replay

######################
main()
pygame.quit()
